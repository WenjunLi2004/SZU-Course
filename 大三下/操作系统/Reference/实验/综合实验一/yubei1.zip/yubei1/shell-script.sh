#!/usr/bin/bash
echo "Running a shell script"
./helloworld
